"""Simple correlation + max-Sharpe + year-by-year Laura Gao projections."""
from __future__ import annotations

import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st

from optimizer import (
    OptimizerError, portfolio_from_prices, project_wharton, weights_table,
    load_prices_csv, portfolio_daily_returns,
)
from market_data import download_adjusted_prices

st.set_page_config(page_title='Laura Gao | Simple Portfolio Optimizer', layout='wide')
st.title('Laura Gao — Simple Portfolio Optimizer')
st.caption('Correlation · Maximum Sharpe ratio · Wharton year-by-year projection')
st.info('Wharton projection rules: $300,000 at the beginning of 2027; $150,000 at the beginning of 2028; ten fixed $50,000 operating payments at the beginnings of 2033–2042. WInS returns are NOT used as starting capital.')

with st.sidebar:
    st.header('1 · Select assets')
    source = st.radio('Historical adjusted prices', ['Download tickers', 'Upload CSV'], index=0)
    tickers_raw = st.text_input('Tickers (comma separated)', 'VTI, VBR, VXUS, SGOV, BND')
    tickers = list(dict.fromkeys(t.strip().upper().replace('BRK.B', 'BRK-B') for t in tickers_raw.split(',') if t.strip()))
    years = st.select_slider('Historical data window (years)', options=[2, 3, 5, 7, 10], value=5)
    uploaded = st.file_uploader('CSV: Date,TICKER1,TICKER2,... adjusted prices', type=['csv']) if source == 'Upload CSV' else None
    st.header('2 · Max Sharpe settings')
    risk_free_pct = st.number_input('Risk-free annual rate (%)', value=3.0, min_value=-5.0, max_value=25.0, step=0.25)
    max_weight_pct = st.slider('Maximum asset allocation (%)', 10, 100, 60, 5)
    shrinkage_pct = st.slider('Covariance stabilization (%)', 0, 30, 5, 1)
    st.header('3 · Wharton projections')
    st.caption('Recommended: use a separately justified forward growth assumption, not raw historical returns.')
    return_method = st.radio('Annual projection growth', ['Assumption (recommended)', 'Historical optimized mean (illustrative)'])
    assumption_pct = st.number_input('Assumed annual return (%)', value=6.0, min_value=-50.0, max_value=100.0, step=0.5,
                                     disabled=return_method != 'Assumption (recommended)')
    stop_2033 = st.checkbox('Show projection only through 2033', value=False)
    include_payments = st.checkbox('Include Wharton operating payments', value=True)
    wins_capital = st.number_input('Illustrative WInS portfolio balance ($)', min_value=0.0, value=100_000.0, step=10_000.0)
    run = st.button('Optimize Portfolio', type='primary', use_container_width=True)

if not run:
    st.write('Enter your tickers, select a data source and choose **Optimize Portfolio**. The allocation maximizes estimated Sharpe ratio under a long-only asset-weight cap.')
    with st.expander('CSV example format'):
        st.code('Date,VTI,VBR,VXUS,SGOV\n2022-01-03,100.12,81.23,50.12,99.90\n2022-01-04,100.42,80.98,49.86,99.91\n... at least 101 overlapping price dates ...', language='text')
    st.stop()

try:
    if source == 'Download tickers':
        with st.spinner('Downloading price history...'):
            prices = download_adjusted_prices(tickers, years)
    else:
        if uploaded is None:
            raise OptimizerError('Upload your CSV before optimizing.')
        prices = load_prices_csv(uploaded)
        if tickers and all(t in prices.columns for t in tickers):
            prices = prices.loc[:, tickers]
    selected = list(prices.columns)
    if max_weight_pct / 100 < 1 / len(selected) - 1e-9:
        raise OptimizerError(f'{len(selected)} assets require a maximum weight at least {100/len(selected):.1f}%.')
    result, correlations, daily = portfolio_from_prices(
        prices, risk_free=risk_free_pct / 100,
        max_weight=max_weight_pct / 100, shrinkage=shrinkage_pct / 100,
    )
    forward_growth = assumption_pct / 100 if return_method == 'Assumption (recommended)' else result.expected_return
    if forward_growth <= -1:
        raise OptimizerError('Annual projected return cannot be -100% or lower.')
    projected = project_wharton(forward_growth, through_year=2033 if stop_2033 else 2042,
                                 include_operating_payments=include_payments)
    weights = weights_table(result, wins_capital)
except (OptimizerError, KeyError, ValueError) as exc:
    st.error(f'Cannot calculate portfolio: {exc}')
    st.stop()
except Exception as exc:
    st.error(f'Unexpected data/provider error: {exc}')
    st.stop()

st.subheader('Optimized portfolio')
a,b,c,d = st.columns(4)
a.metric('Expected annual arithmetic return', f'{result.expected_return:.2%}')
b.metric('Annualized volatility', f'{result.volatility:.2%}')
c.metric('Maximum estimated Sharpe', f'{result.sharpe:.3f}')
d.metric('Assumed annual projection return', f'{forward_growth:.2%}')
st.caption('Historical expected return and volatility are estimates from observed adjusted daily prices. Sharpe uses the selected annual risk-free rate; projection return may be different by design.')
left,right = st.columns([1,1])
with left:
    fig = px.bar(weights.sort_values('Weight %'), x='Weight %', y='Ticker', orientation='h',
                 title='Max-Sharpe allocation')
    fig.update_layout(yaxis_title='', xaxis_title='Portfolio weight (%)')
    st.plotly_chart(fig, use_container_width=True)
with right:
    st.dataframe(weights.style.format({'Weight': '{:.4f}', 'Weight %':'{:.2f}',
                                      'Illustrative WInS Dollars':'${:,.2f}'}), hide_index=True, use_container_width=True)
    st.download_button('Download allocation CSV', weights.to_csv(index=False).encode(),
                       'max_sharpe_allocation.csv', 'text/csv')

st.subheader('Correlation of daily returns')
st.caption(f'{len(daily):,} overlapping daily observations · {daily.index.min():%b %Y}–{daily.index.max():%b %Y}. Correlation ranges from −1 to +1.')
fig = px.imshow(correlations, color_continuous_scale='RdBu_r', range_color=[-1,1],
                text_auto='.2f', aspect='auto', title='Pairwise correlation heatmap')
st.plotly_chart(fig, use_container_width=True)
st.download_button('Download correlations CSV', correlations.to_csv().encode(), 'correlations.csv', 'text/csv')

st.subheader('Year-by-year Wharton financial projection')
if return_method.startswith('Historical'):
    st.warning('You selected the historical arithmetic expected return for compounding. This is a simplified illustration and may significantly overstate or understate a reasonable forward return.')
else:
    st.caption('The annual growth rate is an editable modeling assumption, not a guaranteed investment return or a rate specified by Wharton.')
first_2033 = projected.loc[projected['Year']==2033]
a,b,c = st.columns(3)
a.metric('End-2032 portfolio (before 2033 payment)',
         f"${projected.loc[projected['Year']==2032, 'Year-End Balance'].iloc[0]:,.0f}" if len(projected) > 1 else 'n/a')
b.metric('End-2033 portfolio', f"${first_2033['Year-End Balance'].iloc[0]:,.0f}")
c.metric(f"End-{int(projected['Year'].iloc[-1])} portfolio", f"${projected['Year-End Balance'].iloc[-1]:,.0f}")
fig = px.line(projected, x='Year', y='Year-End Balance', markers=True,
              title='Year-end portfolio balances (deterministic projection)')
st.plotly_chart(fig, use_container_width=True)
cols = ['Year','Opening Balance','Beginning Contribution','Requested Operating Payment',
        'Funded Operating Payment', 'Unfunded Operating Payment','Annual Investment Earnings','Year-End Balance']
st.dataframe(projected[cols].style.format({col:'${:,.2f}' for col in cols if col!='Year'}),
             use_container_width=True, hide_index=True)
st.download_button('Download full annual projection CSV', projected.to_csv(index=False).encode(),
                   'laura_gao_year_by_year.csv', 'text/csv')
if projected['Unfunded Operating Payment'].sum() > 1e-8:
    st.error('The assumed return produces UNFUNDED annual operating payments. The projection does not borrow money or assume external assistance.')
else:
    st.success('All modeled operating payments within the chosen projection horizon are funded in this constant-return illustration. This is NOT evidence of a high funding probability.')

with st.expander('Method and scope — important'):
    st.markdown('''- **Max-Sharpe calculation:** maximize `(portfolio annual arithmetic return − risk-free rate) / annualized volatility` through a convex transformation, with nonnegative weights, weights summing to 100%, and your per-asset cap.
- **Estimation:** arithmetic daily mean × 252; sample daily covariance × 252, optionally shrunk toward its diagonal. Correlations use daily simple returns, not prices. Historical estimates are not forward guarantees.
- **Cash-flow timing:** each year's contribution and required operating payment occur at the **beginning** of the year, before that year's investment earnings. Annual earnings equal the amount remaining invested after those flows times the assumed annual return.
- **2033–2042 operating commitment:** ten nominal $50,000 payments, no inflation adjustment. The model does not establish an operating reserve or facility contribution and cannot demonstrate high funding certainty.
- **WInS:** dollar amounts in the weight table are solely an illustrative implementation of your chosen WInS balance. They do not enter Laura's long-term projection.
- **Data caveat:** Yahoo Finance adjusted prices approximate distribution-adjusted returns. Different listing histories reduce aligned data. Price/total-return consistency should be checked before making decisions.''')
