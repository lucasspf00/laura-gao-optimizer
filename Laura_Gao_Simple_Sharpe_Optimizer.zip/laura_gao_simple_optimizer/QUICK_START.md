# Quick start — Laura Gao simple optimizer

1. Extract the ZIP.
2. Install Python 3.11+ and dependencies: `python -m pip install -r requirements.txt`.
3. Launch: `python -m streamlit run app.py`.
4. Enter candidates such as **VTI, VBR, VXUS, SGOV, BND** or upload a CSV of actual adjusted-close price histories.
5. Select a risk-free rate and an optional maximum asset weight, then click **Optimize Portfolio**.
6. Read the correlation heatmap, max-Sharpe portfolio weights, and **2027–2042 annual portfolio earnings**.

**Wharton cash flows:** +$300,000 at the beginning of 2027, +$150,000 at the beginning of 2028, then -$50,000 at the beginning of each year 2033 through 2042. The WInS illustrative account balance is separate and does not enter Laura's projections.

**Critical assumption:** The 6% annual growth example is for illustration only. Change it to an investment-return assumption justified by your research. Wharton supplies no required investment return. Historical expected-return estimates used for Sharpe are not reliable as fixed annual return forecasts.

**Scope:** This app does *not* size the mandatory 2033 operating reserve, assess funding probability, or recommend a facility contribution. It cannot, by itself, establish that annual payments can be funded with a high degree of certainty.

**If live downloads do not work:** Supply your own CSV or use `examples/SYNTHETIC_EXAMPLE_NOT_REAL_MARKET_DATA.csv` for an **offline demonstration only**; never trade using its allocations.
