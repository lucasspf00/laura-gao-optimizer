import io

import numpy as np
import pandas as pd
import pytest

from optimizer import (
    OptimizerError, annualized_inputs, clean_prices, load_prices_csv,
    optimize_max_sharpe, portfolio_from_prices, project_wharton,
    returns_from_prices, weights_table,
)


def test_analytic_max_sharpe_2_assets():
    # Diagonal covariance. Tangency weights are proportional to Sigma^-1 * excess.
    mu = pd.Series([0.11, 0.15], index=['A', 'B'])
    cov = pd.DataFrame(np.diag([0.04, 0.09]), index=mu.index, columns=mu.index)
    p = optimize_max_sharpe(mu, cov, risk_free=0.03)
    assert p.weights.sum() == pytest.approx(1)
    np.testing.assert_allclose(p.weights, [0.6, 0.4], atol=1e-5)
    assert p.sharpe == pytest.approx(np.sqrt(0.08**2/0.04 + 0.12**2/0.09), rel=1e-6)


def test_asset_cap():
    mu = pd.Series([0.11, 0.15], index=['A', 'B'])
    cov = pd.DataFrame(np.diag([0.04, 0.09]), index=mu.index, columns=mu.index)
    p = optimize_max_sharpe(mu, cov, risk_free=0.03, max_weight=0.55)
    assert p.weights.max() <= 0.55000001
    np.testing.assert_allclose(p.weights, [0.55, 0.45], atol=1e-5)


def test_impossible_cap():
    mu = pd.Series([0.1, 0.12], index=['A', 'B'])
    cov = pd.DataFrame(np.diag([0.04, 0.03]), index=mu.index, columns=mu.index)
    with pytest.raises(OptimizerError, match='Maximum weight'):
        optimize_max_sharpe(mu, cov, max_weight=0.40)


def test_excess_return_infeasible():
    mu = pd.Series([0.01, 0.02], index=['A', 'B'])
    cov = pd.DataFrame(np.diag([0.04, 0.03]), index=mu.index, columns=mu.index)
    with pytest.raises(OptimizerError, match='No feasible portfolio'):
        optimize_max_sharpe(mu, cov, risk_free=0.03)


def test_cap_makes_positive_excess_infeasible():
    mu = pd.Series([0.21, -0.31], index=['A', 'B'])
    cov = pd.DataFrame(np.diag([0.04, 0.03]), index=mu.index, columns=mu.index)
    with pytest.raises(OptimizerError, match='No feasible portfolio'):
        optimize_max_sharpe(mu, cov, risk_free=0.03, max_weight=0.50)


def test_two_contributions_and_annual_growth():
    p = project_wharton(annual_growth=0.06, through_year=2029, include_operating_payments=False)
    first, second, third = p.iloc[0], p.iloc[1], p.iloc[2]
    assert first['Opening Balance'] == 0
    assert first['Beginning Contribution'] == 300000
    assert first['Annual Investment Earnings'] == pytest.approx(18000)
    assert first['Year-End Balance'] == pytest.approx(318000)
    assert second['Beginning Contribution'] == 150000
    assert second['Invested After Beginning Flows'] == pytest.approx(468000)
    assert second['Annual Investment Earnings'] == pytest.approx(28080)
    assert third['Beginning Contribution'] == 0
    assert third['Year-End Balance'] == pytest.approx(second['Year-End Balance'] * 1.06)


def test_first_2033_payment_before_earnings():
    p = project_wharton(annual_growth=0.06, through_year=2033)
    before = p[p['Year'] == 2032].iloc[0]['Year-End Balance']
    first = p[p['Year'] == 2033].iloc[0]
    assert first['Opening Balance'] == pytest.approx(before)
    assert first['Requested Operating Payment'] == 50000
    assert first['Invested After Beginning Flows'] == pytest.approx(before - 50000)
    assert first['Annual Investment Earnings'] == pytest.approx((before - 50000) * 0.06)


def test_ten_operating_payments():
    p = project_wharton(annual_growth=0.06, through_year=2042)
    assert p['Requested Operating Payment'].sum() == 500000
    assert (p['Requested Operating Payment'] > 0).sum() == 10
    assert list(p.loc[p['Requested Operating Payment'] > 0, 'Year']) == list(range(2033, 2043))
    assert p['Beginning Contribution'].sum() == 450000
    assert (p['Unfunded Operating Payment'] == 0).all()


def test_shortfall_does_not_mint_or_borrow_money():
    p = project_wharton(annual_growth=-0.95)
    assert p['Unfunded Operating Payment'].sum() > 0
    assert p['Year-End Balance'].min() >= 0
    np.testing.assert_allclose(p['Funded Operating Payment'] + p['Unfunded Operating Payment'],
                               p['Requested Operating Payment'])


def test_projection_no_operating_payments():
    p = project_wharton(annual_growth=0.06, include_operating_payments=False)
    assert p['Requested Operating Payment'].sum() == 0
    assert p['Beginning Contribution'].sum() == 450000


def test_negative_return_allowed():
    p = project_wharton(-0.10, through_year=2027)
    assert p['Annual Investment Earnings'].iloc[0] == -30000
    assert p['Year-End Balance'].iloc[0] == 270000


def test_invalid_return_rejected():
    with pytest.raises(OptimizerError):
        project_wharton(-1)


def test_invalid_year_rejected():
    with pytest.raises(OptimizerError):
        project_wharton(0.06, through_year=2043)


def test_price_input_and_alignment():
    dates = pd.bdate_range('2025-01-01', periods=150)
    rng = np.random.default_rng(117)
    increments = rng.normal(0.00035, 0.01, size=(150,3))
    prices = pd.DataFrame(100*np.exp(increments.cumsum(axis=0)), index=dates, columns=['AAA','BBB','CCC'])
    prices.iloc[40, 0] = np.nan
    cleaned = clean_prices(prices)
    assert len(cleaned) == 149
    assert all(cleaned.index == cleaned.index.sort_values())
    r = returns_from_prices(cleaned)
    assert len(r) == len(cleaned) - 1
    mu, cv = annualized_inputs(r, shrinkage=0.05)
    assert np.linalg.eigvalsh(cv).min() >= -1e-10
    p, c, daily = portfolio_from_prices(cleaned, risk_free=-0.05, max_weight=0.70)
    assert np.isclose(p.weights.sum(), 1)
    assert max(p.weights) <= 0.700001
    np.testing.assert_allclose(c.values.diagonal(), np.ones(3), atol=1e-10)
    t = weights_table(p, wins_capital=100000)
    assert t['Illustrative WInS Dollars'].sum() == pytest.approx(100000)


def test_csv_round_trip():
    dates = pd.bdate_range('2025-01-01', periods=110)
    frame = pd.DataFrame({'Date': dates, 'VTI': np.arange(110) + 100.0,
                          'VXUS': np.arange(110)*0.9 + 90.0})
    prices = load_prices_csv(io.BytesIO(frame.to_csv(index=False).encode()))
    assert list(prices.columns) == ['VTI','VXUS']


def test_zero_volatility_series_errors():
    dates = pd.bdate_range('2025-01-01', periods=150)
    frame = pd.DataFrame({'AAA': np.repeat(100.0,150), 'BBB': 100+np.arange(150)}, index=dates)
    with pytest.raises(OptimizerError, match='No meaningful price variation'):
        returns_from_prices(frame)


def test_duplicate_dates_error():
    dates = list(pd.bdate_range('2025-01-01', periods=110))
    dates[5] = dates[4]
    frame = pd.DataFrame({'A': np.arange(110)+20, 'B': np.arange(110)+25}, index=dates)
    with pytest.raises(OptimizerError, match='Duplicate dates'):
        clean_prices(frame)


def test_cash_flows_unchanged_by_illustrative_wins_dollars():
    p = project_wharton(0.06, through_year=2033)
    assert p['Beginning Contribution'].sum() == 450000
    assert p['Requested Operating Payment'].sum() == 50000


def test_projection_2031_2032_no_outflows():
    p = project_wharton(0.06)
    for y in (2029, 2030, 2031, 2032):
        r = p[p.Year == y].iloc[0]
        assert r['Beginning Contribution'] == 0
        assert r['Requested Operating Payment'] == 0


def test_all_operating_payments_beginning_of_year_even_zero_growth():
    p = project_wharton(0.0)
    at_2033 = p[p.Year == 2033].iloc[0]
    assert at_2033['Opening Balance'] == 450000
    assert at_2033['Invested After Beginning Flows'] == 400000
    assert p['Unfunded Operating Payment'].sum() == 50000
    assert p['Year-End Balance'].iloc[-1] == 0


def test_calibrated_max_sharpe_at_least_as_good_as_random_feasible_weights():
    mu = pd.Series([0.09, 0.15, 0.08, 0.12], index=['A','B','C','D'])
    matrix = np.array([[0.05,0.01,0.00,0.02], [0.01,0.08,0.015,0.01],
                       [0.,0.015,0.06,0.00], [0.02,0.01,0.,0.07]])
    cov = pd.DataFrame(matrix, index=mu.index, columns=mu.index)
    solution = optimize_max_sharpe(mu, cov, risk_free=0.03, max_weight=0.5)
    random = np.random.default_rng(99).dirichlet(np.ones(4), size=10000)
    feasible = random[random.max(axis=1) <= 0.5]
    excess = (mu.to_numpy() - 0.03)
    numer = feasible @ excess
    denominator = np.sqrt(np.einsum('bi,ij,bj->b', feasible, matrix, feasible))
    assert solution.sharpe + 1e-5 >= max(numer / denominator)
