"""Optional market-download adapter. Network access required on the user's machine."""
from __future__ import annotations

import pandas as pd
from optimizer import clean_prices, OptimizerError


def download_adjusted_prices(tickers: list[str], history_years: int = 5) -> pd.DataFrame:
    if not 1 <= history_years <= 20:
        raise OptimizerError('History years must be between 1 and 20.')
    if len(tickers) < 2:
        raise OptimizerError('Enter at least two tickers.')
    try:
        import yfinance as yf
    except ImportError as exc:
        raise OptimizerError('Install yfinance with: pip install -r requirements.txt') from exc
    # Auto-adjusted close approximates a corporate-action/distribution adjusted
    # price series. No guarantee about precision or live data availability.
    # Yahoo Finance supports a fixed set of period tokens. Explicit start/end
    # dates work for arbitrary 3- and 7-year selections as well.
    end = pd.Timestamp.now(tz='UTC').tz_localize(None).normalize() + pd.Timedelta(days=1)
    start = end - pd.DateOffset(years=history_years)
    data = yf.download(tickers, start=start.strftime('%Y-%m-%d'),
                       end=end.strftime('%Y-%m-%d'), interval='1d',
                       auto_adjust=True, progress=False, threads=False)
    if data is None or data.empty:
        raise OptimizerError('No Yahoo Finance data returned; try CSV import.')
    if isinstance(data.columns, pd.MultiIndex):
        lvl0 = data.columns.get_level_values(0)
        lvl1 = data.columns.get_level_values(1)
        if 'Close' in lvl0:
            prices = data['Close']
        elif 'Close' in lvl1:
            prices = data.xs('Close', axis=1, level=1)
        else:
            raise OptimizerError('Yahoo Finance result has no Close prices.')
    else:
        if 'Close' not in data.columns:
            raise OptimizerError('Yahoo Finance result has no Close prices.')
        if len(tickers) != 1:
            raise OptimizerError('Yahoo Finance omitted requested tickers; use CSV import.')
        prices = data[['Close']].rename(columns={'Close': tickers[0]})
    prices.columns = [str(t).upper() for t in prices.columns]
    absent = [t for t in tickers if t not in prices.columns]
    if absent:
        raise OptimizerError('Missing assets in downloaded prices: ' + ', '.join(absent))
    return clean_prices(prices.loc[:, tickers])
