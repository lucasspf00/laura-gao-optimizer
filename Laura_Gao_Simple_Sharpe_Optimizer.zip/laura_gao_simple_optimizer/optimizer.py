"""Correlation, long-only maximum-Sharpe optimization and Laura Gao cash flows.

A narrowly scoped tool, not a funding-certainty or operating-reserve model.
"""
from __future__ import annotations

from dataclasses import dataclass
from io import BytesIO
from typing import Iterable

import numpy as np
import pandas as pd
from scipy.optimize import minimize

TRADING_DAYS = 252
START_YEAR = 2027
END_YEAR = 2042
OPERATING_FIRST_YEAR = 2033
OPERATING_LAST_YEAR = 2042
OPERATING_PAYMENT = 50_000.0
INITIAL_CONTRIBUTIONS = {2027: 300_000.0, 2028: 150_000.0}


class OptimizerError(ValueError):
    """User-correctable input or optimization problem."""


@dataclass(frozen=True)
class Portfolio:
    tickers: tuple[str, ...]
    weights: np.ndarray
    expected_return: float
    volatility: float
    sharpe: float
    risk_free: float
    covariance_shrinkage: float


def clean_prices(prices: pd.DataFrame, min_observations: int = 100) -> pd.DataFrame:
    """Validate and align an adjusted-close price matrix; never fabricate gaps."""
    if not isinstance(prices, pd.DataFrame) or prices.empty:
        raise OptimizerError("No price data supplied.")
    data = prices.copy()
    if 'Date' in data.columns:
        data['Date'] = pd.to_datetime(data['Date'], errors='coerce')
        if data['Date'].isna().any():
            raise OptimizerError("CSV contains invalid values in the Date column.")
        data = data.set_index('Date')
    if not isinstance(data.index, pd.DatetimeIndex):
        try:
            data.index = pd.to_datetime(data.index, errors='raise')
        except Exception as exc:
            raise OptimizerError("Prices must have a date index or Date column.") from exc
    if data.index.has_duplicates:
        raise OptimizerError("Duplicate dates detected; remove them before running.")
    data = data.sort_index()
    data.columns = [str(col).strip().upper() for col in data.columns]
    if len(set(data.columns)) != len(data.columns):
        raise OptimizerError("Duplicate ticker columns after normalization.")
    for col in data.columns:
        data[col] = pd.to_numeric(data[col], errors='coerce')
    if (data.select_dtypes(include='number') <= 0).any().any():
        raise OptimizerError("Adjusted prices must be strictly positive.")
    if not np.isfinite(data.to_numpy(dtype=float)[~data.isna().to_numpy()]).all():
        raise OptimizerError("Price data contains non-finite values.")
    initial_rows = len(data)
    data = data.dropna(how='any')
    if len(data) < min_observations + 1:
        raise OptimizerError(
            f"Only {len(data)} common price dates remain after alignment "
            f"(from {initial_rows}); need at least {min_observations + 1}. "
            "Remove assets with sparse histories or use a longer date range."
        )
    if data.shape[1] < 2:
        raise OptimizerError("Enter at least two assets to calculate correlations.")
    return data


def load_prices_csv(uploaded_file: BytesIO | bytes) -> pd.DataFrame:
    """CSV columns: Date,TICKER1,TICKER2,... with adjusted-close prices."""
    try:
        frame = pd.read_csv(BytesIO(uploaded_file) if isinstance(uploaded_file, bytes) else uploaded_file)
    except Exception as exc:
        raise OptimizerError(f"Cannot read CSV: {exc}") from exc
    if 'Date' not in frame.columns:
        raise OptimizerError("CSV must include a Date column.")
    return clean_prices(frame)


def returns_from_prices(prices: pd.DataFrame) -> pd.DataFrame:
    """Aligned daily simple returns, with no forward filling or synthetic prices."""
    prices = clean_prices(prices)
    returns = prices.pct_change(fill_method=None).dropna(how='any')
    if len(returns) < 100:
        raise OptimizerError("Fewer than 100 common daily return observations.")
    vol = returns.std(ddof=1)
    if (vol < 1e-9).any():
        symbols = ', '.join(vol.index[vol < 1e-9])
        raise OptimizerError(f"No meaningful price variation: {symbols}. Remove or replace those series.")
    return returns


def annualized_inputs(returns: pd.DataFrame, shrinkage: float = 0.05) -> tuple[pd.Series, pd.DataFrame]:
    """Arithmetic annual mean and shrinkage-stabilized annual covariance.

    Shrinkage of sample covariance toward its diagonal keeps the model simple,
    helps nearly collinear portfolios, and is NOT Ledoit-Wolf estimation.
    """
    if not 0 <= shrinkage <= 1:
        raise OptimizerError('Covariance shrinkage must be between 0 and 1.')
    if returns.shape[0] < 100 or returns.shape[1] < 2:
        raise OptimizerError('Need at least 100 return days and two assets.')
    means = returns.mean() * TRADING_DAYS
    raw = returns.cov() * TRADING_DAYS
    diagonal = np.diag(np.diag(raw.to_numpy()))
    covariance = (1 - shrinkage) * raw.to_numpy() + shrinkage * diagonal
    covariance = (covariance + covariance.T) / 2
    vals, vectors = np.linalg.eigh(covariance)
    if vals.min() < -1e-8:
        raise OptimizerError('Invalid covariance data; check the input returns.')
    if vals.min() < 1e-12:
        vals = np.maximum(vals, 1e-12)
        covariance = (vectors * vals) @ vectors.T
    return means, pd.DataFrame(covariance, index=raw.index, columns=raw.columns)


def _greedy_highest_excess(excess: np.ndarray, cap: float) -> np.ndarray:
    w = np.zeros(len(excess))
    remaining = 1.0
    for j in np.argsort(-excess):
        take = min(cap, remaining)
        w[j] = take
        remaining -= take
        if remaining < 1e-12:
            break
    if remaining > 1e-9:
        raise OptimizerError('Asset weight cap makes the allocation infeasible.')
    return w / w.sum()


def optimize_max_sharpe(
    annual_returns: pd.Series,
    annual_covariance: pd.DataFrame,
    risk_free: float = 0.03,
    max_weight: float = 1.0,
    shrinkage: float = 0.05,
) -> Portfolio:
    """Max Sharpe as a convex minimum-variance transformation when excess > 0.

    Let a = mu - rf; minimize y' Sigma y subject to a'y=1, y>=0,
    y_i <= max_weight * sum(y). Final weights w=y/sum(y).
    The convex objective avoids unstable local maximum-Sharpe searches.
    """
    names = list(annual_returns.index)
    n = len(names)
    if n < 2 or not (1 / n - 1e-12 <= max_weight <= 1):
        raise OptimizerError(f'Maximum weight must be between {1/n:.1%} and 100% for {n} assets.')
    if list(annual_covariance.index) != names or list(annual_covariance.columns) != names:
        raise OptimizerError('Covariance tickers and expected-return tickers do not match.')
    excess = annual_returns.to_numpy(dtype=float) - float(risk_free)
    cov = annual_covariance.to_numpy(dtype=float)
    if not np.isfinite(excess).all() or not np.isfinite(cov).all():
        raise OptimizerError('Expected returns/covariance contain nonfinite data.')
    if np.linalg.eigvalsh(cov).min() < -1e-8:
        raise OptimizerError('Covariance matrix must be positive semidefinite.')
    w0 = _greedy_highest_excess(excess, float(max_weight))
    max_excess = excess @ w0
    if max_excess <= 1e-10:
        raise OptimizerError(
            'No feasible portfolio has expected return above the selected risk-free rate. '
            'Lower the risk-free rate only if justified, change the candidate assets, '
            'or use forward-looking expected-return assumptions. '
            'A positive maximum-Sharpe portfolio cannot be produced from these inputs.'
        )
    y0 = w0 / max_excess
    # Objective and constraints are convex/linear; SLSQP is used for numerical solving.
    inequalities = []
    for i in range(n):
        row = np.full(n, max_weight)
        row[i] -= 1.0
        inequalities.append({'type': 'ineq', 'fun': lambda y, r=row: float(r @ y),
                             'jac': lambda y, r=row: r})
    constraints = [{'type': 'eq', 'fun': lambda y: float(excess @ y - 1),
                    'jac': lambda y: excess}, *inequalities]
    result = minimize(
        lambda y: float(y @ cov @ y), y0,
        jac=lambda y: 2 * cov @ y,
        method='SLSQP',
        bounds=[(0, None)] * n,
        constraints=constraints,
        options={'maxiter': 2500, 'ftol': 1e-12},
    )
    if not result.success and abs(excess @ result.x - 1) > 1e-6:
        raise OptimizerError(f'Numerical optimizer failed: {result.message}')
    y = result.x
    if np.any(y < -1e-7) or y.sum() <= 0:
        raise OptimizerError('Optimizer returned invalid nonnegative weights.')
    w = np.maximum(y, 0)
    w /= w.sum()
    if abs(w.sum() - 1) > 1e-7 or w.max() > max_weight + 1e-6:
        raise OptimizerError('Optimization did not satisfy portfolio weight constraints.')
    expected = float(w @ annual_returns.to_numpy())
    variance = float(w @ cov @ w)
    if variance <= 0:
        raise OptimizerError('Estimated portfolio volatility is zero; cannot compute Sharpe.')
    volatility = float(np.sqrt(variance))
    sharpe = (expected - risk_free) / volatility
    return Portfolio(tuple(names), w, expected, volatility, sharpe, risk_free, shrinkage)


def portfolio_from_prices(
    prices: pd.DataFrame, risk_free: float = 0.03,
    max_weight: float = 1.0, shrinkage: float = 0.05,
) -> tuple[Portfolio, pd.DataFrame, pd.DataFrame]:
    daily = returns_from_prices(prices)
    corr = daily.corr()
    mu, cov = annualized_inputs(daily, shrinkage=shrinkage)
    result = optimize_max_sharpe(mu, cov, risk_free, max_weight, shrinkage)
    return result, corr, daily


def project_wharton(
    annual_growth: float = 0.06,
    through_year: int = END_YEAR,
    include_operating_payments: bool = True,
) -> pd.DataFrame:
    """Deterministic nominal annual projection with beginning-of-year flows.

    2027: +$300k, 2028: +$150k. 2033-2042: -$50k at the
    BEGINNING of the year if operating payments are included.
    Does not calculate the 2033 reserve or a facility contribution.
    """
    if not (-1 < annual_growth <= 5):
        raise OptimizerError('Annual growth must be greater than -100% and at most 500%.')
    if not START_YEAR <= through_year <= END_YEAR:
        raise OptimizerError('End year must be between 2027 and 2042.')
    wealth = 0.0
    cumulative_contributions = 0.0
    cumulative_payments = 0.0
    rows = []
    for year in range(START_YEAR, through_year + 1):
        opening = wealth
        contribution = INITIAL_CONTRIBUTIONS.get(year, 0.0)
        requested = float(OPERATING_PAYMENT if include_operating_payments and
                          OPERATING_FIRST_YEAR <= year <= OPERATING_LAST_YEAR else 0.0)
        available = max(0.0, opening + contribution)
        funded = min(requested, available)
        shortfall = requested - funded
        start_invested = available - funded
        income = start_invested * float(annual_growth)
        wealth = start_invested + income
        cumulative_contributions += contribution
        cumulative_payments += funded
        rows.append({
            'Year': year,
            'Opening Balance': opening,
            'Beginning Contribution': contribution,
            'Requested Operating Payment': requested,
            'Funded Operating Payment': funded,
            'Unfunded Operating Payment': shortfall,
            'Invested After Beginning Flows': start_invested,
            'Annual Investment Earnings': income,
            'Year-End Balance': wealth,
            'Cumulative Contributions': cumulative_contributions,
            'Cumulative Payments Funded': cumulative_payments,
        })
    return pd.DataFrame(rows)


def weights_table(portfolio: Portfolio, wins_capital: float = 100_000) -> pd.DataFrame:
    if wins_capital < 0:
        raise OptimizerError('WInS hypothetical balance must not be negative.')
    return pd.DataFrame({
        'Ticker': portfolio.tickers,
        'Weight': portfolio.weights,
        'Weight %': 100 * portfolio.weights,
        'Illustrative WInS Dollars': portfolio.weights * wins_capital,
    }).sort_values('Weight', ascending=False, ignore_index=True)


def portfolio_daily_returns(daily_returns: pd.DataFrame, portfolio: Portfolio) -> pd.Series:
    return pd.Series(daily_returns.loc[:, list(portfolio.tickers)].to_numpy() @ portfolio.weights,
                     index=daily_returns.index, name='Optimized Daily Return')
