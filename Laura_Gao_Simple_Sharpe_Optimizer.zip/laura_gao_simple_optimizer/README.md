# Laura Gao — Simple Correlation & Max-Sharpe Optimizer

A small Python/Streamlit tool for the **2026–2027 Wharton Global High School Investment Competition**. It does three things:

1. Calculates pairwise correlations of **daily investment returns** for tickers you select.
2. Finds the estimated **maximum Sharpe ratio** long-only allocation, subject to an optional per-asset maximum weight.
3. Shows **2027–2042 year-by-year annual earnings and balances** based on Wharton's specified contributions and operating withdrawals.

It does **not** compute a facility contribution, operating reserve, funding probability, or guaranteed return. It is not a replacement for the case study's full operating-funding analysis.

## Install and run

Install Python 3.11 or later. From the folder containing `app.py`:

```bash
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

Enter a list of tickers (default `VTI,VBR,VXUS,SGOV,BND`). Select **Download tickers** to obtain Yahoo Finance history (requires internet) or **Upload CSV** to supply historical daily *adjusted-close* prices. Click **Optimize Portfolio**.

**CSV format** (minimum 101 dates shared by all assets):

```csv
Date,VTI,VBR,VXUS
2024-01-02,210.00,175.12,58.33
2024-01-03,207.89,171.90,58.01
```

The two-row CSV above is only a format illustration and cannot be optimized. A longer, synthetic test-only CSV is provided at `examples/SYNTHETIC_EXAMPLE_NOT_REAL_MARKET_DATA.csv`. To test it, select Upload CSV, choose that file, set max weight to 60%, and click Optimize. **Never use its estimated returns/weights for actual trades.**

## Portfolio mathematics

From adjusted-price daily simple returns `r_t = P_t/P_(t-1) - 1`:

- Pairwise asset correlation: Pearson correlation of daily returns.
- Arithmetic annual expected return for each asset: `mu = 252 * mean(r)`.
- Annual covariance: `Sigma = 252 * cov(r)` with optional *fixed diagonal shrinkage* `S = (1-alpha)*Sigma + alpha*diag(Sigma)` (default 5%; **not** Ledoit–Wolf).
- Portfolio expected return: `E[R_p] = w^T mu`.
- Portfolio volatility: `sigma_p = sqrt(w^T Sigma w)`.
- Sharpe ratio: `(E[R_p] - r_f) / sigma_p`.
- Constraints: `sum(w)=1`, `0<=w_i<=max_weight`. No leverage or shorts.

When at least one feasible portfolio has positive estimated excess return, maximizing Sharpe is equivalent to a convex quadratic problem in the transformed holdings `y`: minimize `y^T Sigma y`, subject to `(mu-r_f)^T y=1`, `y>=0`, `y_i<=cap*sum(y)`. Convert to weights `w=y/sum(y)`. SciPy's SLSQP numerically solves this convex objective with linear constraints; numerical solver accuracy is checked before displaying weights. If no positive-excess portfolio is feasible, it reports an error rather than an invented Sharpe optimum.

**Clarification:** The maximum-Sharpe portfolio is *not necessarily* the minimum-volatility portfolio. Its result is sensitive to expected-return estimates, time windows, and risk-free rate. Return history is not a future forecast.

## Wharton cash flows, exact timing

From the **2026–2027 Client Case Study, pages 2–4**:

- 2026: Year 0, no portfolio yet.
- Beginning of **2027**: add **$300,000**.
- Beginning of **2028**: add **$150,000**.
- **2033–2042:** ten **$50,000** operating payments, one at the **beginning** of each year; nominal fixed dollars.
- No other contributions or withdrawals before 2033.

The **Wharton Investment Competition Guide, pages 2–3** specifies that WInS simulation gains/losses **must not** be used as the beginning balance for Laura's real-world long-term projections. An adjustable WInS notional account appears only in the illustrative allocation table.

For each projection year `y`:

```
opening_y           = closing_(y-1)   [opening_2027 = 0]
contribution_y      = 300000 if 2027, 150000 if 2028, else 0
required_payment_y  = 50000 if 2033<=y<=2042, else 0
available_y         = opening_y + contribution_y
funded_payment_y    = min(available_y, required_payment_y)
shortfall_y         = required_payment_y - funded_payment_y
amount_invested_y   = available_y - funded_payment_y
earnings_y          = amount_invested_y * assumed_annual_growth
closing_y           = amount_invested_y + earnings_y
```

The annual growth assumption **defaults to 6% solely as a user-editable illustration**; Wharton does not prescribe that rate. The recommended mode lets you set a defensible forward return separately from the noisy historical expected return used to calculate Sharpe. You can alternatively project using the historical optimized arithmetic estimate, but that is especially unreliable as a compounded annual forecast.

**This is a deterministic single-return projection.** It cannot prove a high probability of funding all 10 payments, and does not model the 2033 operating reserve, facility contribution, or separate retained liquidity. The app flags years with unfunded payments instead of inventing a loan.

## Outputs

- Maximum-Sharpe weights, annual historical mean, annual volatility, Sharpe.
- Pairwise daily-return correlation heatmap and downloadable correlation CSV.
- WInS allocation amounts using a separate, editable hypothetical account balance.
- One row per year showing opening balance, beginning-of-year contribution, required/funded operating payment, annual investment earnings, and year-end balance.
- CSV downloads for allocation and projection.

## Test

```bash
python -m pytest -q
```

The tests use artificial data to verify allocation mathematics, cash-flow timing, shortfall handling, and CSV import. They do not verify live Yahoo Finance availability.

An illustrative 6% projection CSV, **not an empirical forecast**, is included in `examples/WHARTON_6PCT_ASSUMPTION_ILLUSTRATION.csv` so you can inspect all 16 annual rows without running the Streamlit interface.
